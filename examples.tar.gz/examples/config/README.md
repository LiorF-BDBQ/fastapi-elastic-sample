Directory containing example configuration files to be bundled with release artifacts.
